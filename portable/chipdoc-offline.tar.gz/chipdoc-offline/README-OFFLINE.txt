chipdoc 离线包（Windows x64，自带 Python 运行时，无需安装任何依赖）
============================================================

  run.cmd doctor 手册.pdf
  run.cmd prepare 手册.pdf --work work --batch 4
  run.cmd finish work\<slug> --out out

运行时：CPython 3.12.7（Windows x64）
PyMuPDF：1.28.2

验证：run.cmd where   应显示 PDF 后端 pymupdf

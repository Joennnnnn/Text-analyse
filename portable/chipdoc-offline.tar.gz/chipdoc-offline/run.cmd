@echo off
setlocal
set "DIR=%~dp0"
set "PYTHONPATH=%DIR%site-packages"
if exist "%DIR%plugins" set "CHIPDOC_PLUGINS=%DIR%plugins"
"%DIR%runtime\python\python.exe" -P -m chipdoc %*

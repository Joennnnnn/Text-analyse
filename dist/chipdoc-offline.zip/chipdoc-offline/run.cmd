@echo off
setlocal
set "DIR=%~dp0"
set "PYTHONPATH=%DIR%site-packages"
if exist "%DIR%plugins" set "CHIPDOC_PLUGINS=%DIR%plugins"
if "%~1"=="" (
  "%DIR%runtime\python\python.exe" -P -m chipdoc --help
  echo.
  echo 用法示例：run.cmd doctor 手册.pdf
  pause
  exit /b 0
)
"%DIR%runtime\python\python.exe" -P -m chipdoc %*
if errorlevel 1 pause

@echo off
setlocal
set "DIR=%~dp0"
echo 目录：%DIR%
"%DIR%runtime\python\python.exe" -c "import sys,pymupdf;print('python',sys.version);print('pymupdf',pymupdf.__version__);print('exe',sys.executable)"
pause

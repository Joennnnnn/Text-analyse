@echo off
setlocal
set "DIR=%~dp0"
echo 目录：%DIR%
echo PYTHONHOME=%PYTHONHOME%
echo PYTHONPATH=%PYTHONPATH%
"%DIR%runtime\python\python.exe" -E -s -c "import sys,pymupdf;print('python',sys.version);print('pymupdf',pymupdf.__version__);print('exe',sys.executable)"
pause

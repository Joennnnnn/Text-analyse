chipdoc 离线包（Windows x64，自带 Python 运行时，无需安装任何依赖）
============================================================

1. 把整个文件夹放到纯英文路径（如 D:\tools\chipdoc-offline）
2. 双击 run.cmd 可看到用法（不带参数时会停住）
   如果报 SRE module mismatch，说明系统里有冲突的 PYTHONHOME/PYTHONPATH；
   本包已用 -E -s 隔离，仍报错请运行 diagnose.cmd 并把输出发给开发者。
3. 在命令提示符里执行：

  run.cmd doctor 手册.pdf
  run.cmd prepare 手册.pdf --work work --batch 4
  run.cmd finish work\<slug> --out out

运行时：CPython 3.12.7（Windows x64）
PyMuPDF：1.28.2

验证：run.cmd where   应显示 PDF 后端 pymupdf
